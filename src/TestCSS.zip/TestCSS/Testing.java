package TestCSS;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;

public class Testing {
    public static WebElement getWebElement(WebDriver driver, String cssSelector) {
        return driver.findElement(By.cssSelector(cssSelector));
    }

    public void testColor(WebElement element, String expect_color) {
        String actual_color = Color.fromString(element.getCssValue("color")).asHex();
        Assert.assertEquals(expect_color, actual_color);
    }

    public void testBackgroundColor(WebElement element, String expect_background_color) {
        String actual_background_color = Color.fromString(element.getCssValue("background-color")).asHex();
        Assert.assertEquals(expect_background_color, actual_background_color);
    }

    public void testText(WebElement element, String expect_text) {
        String actual_text = element.getText();
        Assert.assertEquals(expect_text, actual_text);
    }

    public void testValue(WebElement element, String expect_value) {
        String actual_value = element.getAttribute("value");
        Assert.assertEquals(expect_value, actual_value);
    }

    public void testHeight(WebElement element, int expect_height) {
        int actual_height = element.getSize().height;
        Assert.assertEquals(expect_height, actual_height);
    }

    public void testWidth(WebElement element, int expect_width) {
        int actual_width = element.getSize().width;
        Assert.assertEquals(expect_width, actual_width);
    }

}
