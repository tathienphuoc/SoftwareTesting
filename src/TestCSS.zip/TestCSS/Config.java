package TestCSS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Config {
    public static String DriverPath = "/home/thienphuoc/KTPM/geckodriver-v0.29.1-linux64/geckodriver";
    public static String DriverKey = "webdriver.gecko.driver";
    public static String BaseURL = "http://localhost/KTPM/index.php";
    public static WebDriver run(String url){
        System.setProperty(DriverKey, DriverPath);
        WebDriver driver = new FirefoxDriver();
        driver.get(url);
//        driver.manage().window().maximize();
        return driver;
    }
}
